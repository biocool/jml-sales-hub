JML Social Ad Intelligence Dashboard
====================================

This package contains the complete static dashboard, including:

- Paid Ad Intelligence: 800 ads and the downloadable CSV
- Organic Content Intelligence: 300 sourced public records
- JML-branded HTML, CSS, JavaScript, logos and data files

How to open it on macOS
-----------------------

1. Double-click start-dashboard.command.
2. Your browser will open http://localhost:8080.
3. Keep the Terminal window open while using the dashboard.
4. Press Control-C in Terminal to stop the local server.

Manual option
-------------

Open Terminal in this folder and run:

    python3 -m http.server 8080

Then visit http://localhost:8080 in your browser.

Why a local server is needed
----------------------------

The dashboard loads its JSON datasets in the browser. Modern browsers block that
when index.html is opened directly as a file, so the tiny local server is required.

Data note
---------

Pinterest records are public Explore collections and topic pages with limited
metrics. TikTok is a deduplicated sample across official Creative Center rankings.
Missing public metrics are not estimated.
