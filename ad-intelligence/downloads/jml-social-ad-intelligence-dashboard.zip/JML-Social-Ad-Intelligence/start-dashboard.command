#!/bin/zsh
cd "$(dirname "$0")" || exit 1
open "http://localhost:8080"
python3 -m http.server 8080
