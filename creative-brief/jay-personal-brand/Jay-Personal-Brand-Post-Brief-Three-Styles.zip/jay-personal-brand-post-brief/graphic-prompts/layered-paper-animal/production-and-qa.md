# Reference selection, editable construction and QA

## Known references

- [Hare cover module map](assets/cover-map.png): Jay's approved cover field reference; use the hare to judge natural side-profile anatomy, layered shape rhythm, berry/gold/plum and the inset with slips. The raster shows appearance, not source layer count.
- [V5 owl cover](assets/owl-depth-reference.webp): latest supplied VERIFY owl reference in the Jay LinkedIn Carousel Design package, for matte relief, exposed edges and the distinct body window with an interior scene. This is a visual reference, not verification of all editable tiers. Do not substitute the older engraved mustard owl from Post 04.
- For a real anatomy photo, record the actual photographer or organization, original media page, and rights/reuse terms. If unknown, mark them unknown and don't embed the photo in a distributable master. Do not invent artist credits or describe generated reference art as photography.

## Nine inspectable paper sheets

1. Create a master SVG with named groups, or a layered drawing file with equivalent grouping. Lock a separate non-exported anatomy guide. Draw the outer silhouette and identify a body region large enough to hold the motif without sacrificing species features.
2. Draw nine discrete sheet shapes with intentionally stepped cutouts. Use full sheet paths with holes (e.g. SVG even-odd fill) or editable equivalent masks. Name front-to-back `paper-layer-01` through `paper-layer-09`: front rim, inner trim, broad mid-tone step, dark recess, bright step, secondary colored step, deep recess, warm inner rim, rear border. Role labels are starting points, not fixed colors. Assign each a visible exposed edge; at full-size proof the labels must correspond to distinct physical shapes, not nine duplicate outlines.
3. Stack rear to front. Vary band widths to suit anatomy and avoid a mechanically concentric look. Clip separate grain and restrained directionally consistent shadows to each sheet. Put art behind the rear aperture in an independently editable `inset-scene` group, and place anatomy details in separate clearly named groups where appropriate. These groups, background, masks, details and shadows do not count as sheets.
4. Preserve groups, paths, masks and editability on save. Export a transparent PNG with the animal only. Do not rasterize the layered master into a single image or rely on a generator's promise of layers.

## Approval checks

- Open the master and isolate all nine named groups one by one. Check each has its own geometry and exposed edge in the complete view. Toggle each off and on and verify a predictable visual change. Save a layer-list screenshot or contact sheet of nine isolated shapes as verification if handing off a nine-tier claim.
- Inspect the transparent PNG at native dimensions, on both warm paper and dark plum, and at a carousel preview about 360 px wide. At small scale the species, aperture and one core inset cue must still read. At full size check cut edges, believable shadow direction, real alpha, no halos or clipped tips, consistent outline and quiet negative space.
- Reject embossed/engraved effects without stacked edges, external or floating scenes, anatomy drift, artwork that cannot be edited, and fabricated attributions. If the reference wasn't provided or nine groups weren't verified, say exactly which check remains open.
