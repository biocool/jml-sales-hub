# Copy-ready graphic prompt template

Replace bracketed slots before using. This prompt requests a **concept preview**; use the production guide for an actually editable nine-tier master.

```text
Create one isolated editorial paper-cut [species, optionally sex/age if relevant] for Jay Zahiri's personal LinkedIn series. Its visual metaphor is [one concrete decision or contrast]. Use [approved same-species artwork or accurately identified anatomy reference] for natural proportions, pose and expression, and [approved treatment reference] for depth, palette and material only. Do not copy another species' anatomy.

Show [specific gesture/view], with believable [key species features]. Compose the animal as a dominant lower-right cover hero with the whole silhouette inside the frame and slightly more breathing room toward [direction]. Keep the head and tail recognizable at thumbnail size. Use layered berry/magenta, deep plum, warm mustard/gold and cream/kraft paper; let the exact approved reference override these defaults. Use grain on matte paper, visible cut faces and subtle, consistent directional contact shadows. Make successive cut edges visually distinct, not merely stripes over flat fur.

Cut a clearly recessed window wholly inside the [torso/abdomen/shell]. Inside it, use [one primary motif] and [up to two simple supporting forms] to communicate [the decision a viewer should be able to infer]. Keep the inset visually separate from fur or feather markings; use a clean focal silhouette and generous contrast. Do not imply a causal or sequential relationship the post doesn't establish.

Produce an animal-only cutout with true transparent surroundings, clean alpha edges and no cast shadow outside the silhouette. No lettering, numbers, charts, logos, portrait, full slide, scenery outside the animal, border, or watermark. Avoid gradients that mimic plastic, neon, oversized cartoon eyes and icon outlines. The render is a visual target only, not evidence of a verified layer count.
```
