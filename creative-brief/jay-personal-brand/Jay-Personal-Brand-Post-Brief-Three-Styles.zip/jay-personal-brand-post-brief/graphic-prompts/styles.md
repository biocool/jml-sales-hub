# Select a graphics preset

Use a single preset for Module 08. Honor the user's explicit style choice; do not blend presets unless asked. If no style is named, retain the approved artwork and style when editing an existing post. For net-new work, explain the choice in one short line; default to the existing layered paper-animal series only when no distinct visual direction is implied.

| Preset ID | Choose it for | Production prompt | Visual 1–8 mapping |
|---|---|---|---|
| `layered-paper-animal` | Naturalistic die-cut animal with a meaningful scene inside it | [Prompt](layered-paper-animal/prompt.md) · [Production QA](layered-paper-animal/production-and-qa.md) | [Map](layered-paper-animal/assets/cover-map.png) |
| `photo-sketch-mixed-media` | A real object that becomes the working part of a hand-drawn visual metaphor | [Prompt & layout](photo-sketch-mixed-media/prompt.md) | [Map](photo-sketch-mixed-media/assets/cover-map.jpg) |
| `stock-force-lines` | A topical licensed photograph framed by flowing ivory and mustard lines | [Prompt & layout](stock-force-lines/prompt.md) · [SVG composer](../scripts/stock_force_lines.py) | [Map](stock-force-lines/assets/cover-map.jpg) |

Every preset uses the same module IDs, though placement and styling may change. Do not renumber these to match reading order: 1 Topic Label; 2 Series Stamp; 3 Industry Icon; 4 Main Headline; 5 Context & Takeaway; 6 Metric Card (including an unboxed callout); 7 Fixed Brand Footer; 8 Hero Illustration (including its photo and line treatment when relevant). Page numbers and swipe cues are not modules. The demonstration is an example, not a reusable headline or claim.

Use the [actual Jay footer](../assets/approved-jay-footer.png) as a separate, locked asset. The map is for visual guidance, not a source for regenerating his portrait. For a finished carousel, render and review 1080×1350 at both native and phone size. Neither writing a brief nor rendering a draft authorizes publishing.
