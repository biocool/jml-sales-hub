# Module 08 · Photographed object + hand-drawn editorial

Use only for `photo-sketch-mixed-media`. See the [1–8 cover map](assets/cover-map.jpg) and [zipper cutout](assets/zipper-hero.webp). The reference shows composition, not a prop to reuse. Source inspiration: [Larus Canus gallery entry](https://biocool.github.io/jml-image-prompt-gallery/#source/2110735138430824892); [author's separate reusable template](https://x.com/MrLarus/status/2110735508674593058). This is a new Jay adaptation; do not assume an example's original generation inputs or reuse its art.

## Copy-ready hero prompt

Create one isolated editorial illustration on true transparent alpha. The core idea is [decision, contrast or mechanism]. Use one realistically photographed [physical object with recognizable material] that literally becomes [sketched metaphor]. Make this join necessary to the meaning, not decoration: the object must physically connect to the drawing with matching scale and contact. Use loose ink and graphite, irregular handmade marks, subtle fiber or pencil texture, asymmetry, and one controlled accent from the brand palette. Preserve the supplied real object reference if used. No letters, chart elements, headshot, posts, footer, backdrop panel, cartoon gloss, stacked paper-cut layers or generic sector clip art.

## Compose

- Select a prop for the topic, not for the niche shown on the stamp. For example, a zipper splits the same approach into two possible next steps. An unrelated car is not a default for a law-firm post.
- Generate only the hero asset. Place it on the warm cream Jay cover, below or beside the upper-left headline and separated from the metric card. Use a dominant visible hero comparable to the enlarged approved reference (~735px wide on the 1080px cover, when the aspect ratio and safe area allow). Don't compound a prior enlargement; keep type and footer clear.
- Reuse the same visual as a small echo on slide two, with proof and source dominant. Never generate a whole carousel with an image model.
