#!/usr/bin/env python3
"""Build the editable Jay force-lines art layer (not full-carousel typography)."""
from argparse import ArgumentParser
from base64 import b64encode
from math import pi, sin
from pathlib import Path
from xml.etree import ElementTree

MASTER_WIDTH = 1350 * 9 / 16
PAD = 1080 - MASTER_WIDTH
# y, reference-frame photo edge, width, bias. Preserve the x order of strands.
KNOTS = [
 (-100,950,208,.27),(0,829,231,.35),(125,775,226,.44),(248,763,255,.22),
 (363,692,249,-.13),(431,628,192,-.40),(494,599,216,-.73),
 (560,568,266,-.45),(612,538,294,.00),(671,502,293,.56),
 (735,401,269,.68),(797,297,228,.34),(857,270,252,-.35),
 (918,288,266,-.70),(978,289,259,-.43),(1037,229,219,.04),
 (1092,111,171,.51),(1146,33,162,.64),(1194,-60,198,.36),
 (1233,-121,233,.03),(1305,-201,251,-.29),
]
GOLD={6:'#B58B35',13:'#CA9F42',20:'#C59A3C',28:'#DBAB48',36:'#C9A046',44:'#D5A644',50:'#BA913C'}

def spline(strand):
    points=[(x-width*(strand+bias*strand*(1-strand)),y) for y,x,width,bias in KNOTS]
    slopes=[]
    for i in range(len(points)):
        lo,hi=points[max(0,i-1)],points[min(len(points)-1,i+1)]
        slopes.append((hi[0]-lo[0])/(hi[1]-lo[1]))
    path=f'M{points[0][0]:.1f} {points[0][1]}'
    for i,((x,y),(xx,yy)) in enumerate(zip(points,points[1:])):
        span=(yy-y)/3
        path+=f' C{x+slopes[i]*span:.1f} {y+span:.1f} {xx-slopes[i+1]*span:.1f} {yy-span:.1f} {xx:.1f} {yy}'
    return path

def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('photo',type=Path,help='Licensed JPEG or PNG, already color-graded if needed')
    p.add_argument('output',type=Path)
    p.add_argument('--photo-x',type=float,default=486)
    p.add_argument('--photo-y',type=float,default=420)
    p.add_argument('--photo-width',type=float,default=755)
    p.add_argument('--photo-height',type=float,default=944)
    a=p.parse_args()
    photo=a.photo.read_bytes()
    typ='jpeg' if photo.startswith(b'\xff\xd8') else 'png' if photo.startswith(b'\x89PNG\r\n\x1a\n') else None
    if not typ: p.error('photo must be a valid JPEG or PNG')
    if not 0<a.photo_width<=4000 or not 0<a.photo_height<=4000: p.error('invalid viewport size')
    data=b64encode(photo).decode('ascii')
    lines=[]
    for i in range(55):
        d=i/54
        color=GOLD.get(i,'url(#rail)')
        op=(.62+.13*sin(pi*d)) if i in GOLD else (.24+.37*sin(pi*d)**.75-.09*d+(.042 if i%5==0 else 0))
        lines.append(f'<path id="line-{i+1:02}" d="{spline(d)}" fill="none" stroke="{color}" stroke-width="{1.38 if i in GOLD else .92}" opacity="{op:.3f}"/>')
    left=a.photo_x-PAD
    wide=1080
    svg=f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1080" height="1233" viewBox="0 0 1080 1233">
<defs>
 <linearGradient id="plum" x2="100%" y2="100%"><stop stop-color="#15091C"/><stop offset="1" stop-color="#2C0C3B"/></linearGradient>
 <linearGradient id="rail" x2="85%" y2="7%"><stop stop-color="#B8ABBF"/><stop offset=".5" stop-color="#EFE5E9"/><stop offset="1" stop-color="#A898AE"/></linearGradient>
 <linearGradient id="top" x1="0%" y1="42%" x2="0%" y2="65%"><stop stop-color="#210F2E"/><stop offset="1" stop-color="#210F2E" stop-opacity="0"/></linearGradient>
 <linearGradient id="fade" gradientUnits="userSpaceOnUse" x1="{left}" x2="{left+95}"><stop stop-color="black"/><stop offset="1" stop-color="white"/></linearGradient>
 <mask id="softEdge" maskUnits="userSpaceOnUse" x="{-PAD}" y="0" width="{wide}" height="1233"><rect x="{-PAD}" width="{wide}" height="1233" fill="url(#fade)"/></mask>
 <clipPath id="window"><path d="{spline(0)} H1100 V-100 Z"/></clipPath>
</defs>
<rect width="1080" height="1233" fill="url(#plum)"/>
<g transform="translate({PAD} 0)">
 <g id="stock-photo" clip-path="url(#window)">
  <image x="{left}" y="{a.photo_y}" width="{a.photo_width}" height="{a.photo_height}" preserveAspectRatio="xMidYMid slice" mask="url(#softEdge)" xlink:href="data:image/{typ};base64,{data}"/>
  <rect x="{-PAD}" width="{wide}" height="1233" fill="url(#top)"/>
 </g>
 <g id="force-lines">{''.join(lines)}</g>
</g>
</svg>'''
    ElementTree.fromstring(svg)
    a.output.write_text(svg,encoding='utf-8')

if __name__=='__main__':
    main()
