# Editorial calibration from Jay's accepted examples

## The cheaper leads cost more.
- Reusable problem: a metric looks better while the outcome it was meant to represent gets worse.
- Illustrative only: equal spend of $6,000; $50 vs $80 per inquiry; $500 vs $300 per qualified inquiry. The numbers are fictional and keep their stage labels.
- Nuance: separate “not reached” from “reached and not a fit.” Otherwise a higher share of after-hours inquiries can make a campaign look worse because follow-up coverage is uneven. Match follow-up windows when checking campaign quality.
- Art can make the contrast legible with a paper-cut hare and a recessed scene of many inquiry slips narrowing to a few; it need not depict an accident or lawyer. The industry is signaled by the stamp and the car/shield icon.

## The first contact sets the expectation.
- Reusable problem: a phone pickup is measurable, but it doesn't tell you whether a caller understands the next step. A generic “answer faster” tip misses the point.
- Real source: Clio's study reached out to 500 law firms across practice areas. Around 40% answered initially and 52% were reached including callbacks. Do not cast these figures as accident-firm rates or as a JML client result. “Car Accident Law Firms” describes the application of the example.
- Practical test: compare what the ad promises to what the caller actually encounters; a screening call and a free consultation are different expectations.
- Source: https://www.clio.com/guides/client-intake-legal-trends/

## Fully booked. Still waiting.
- Reusable problem: a slot is occupied but the actual work still cannot start.
- Illustrative comparison: 12 vs 21 ready files out of 30 appointment slots per scenario, not an estimated effect of a checklist.
- Nuance: splitting intake by readiness can hide downstream abandonment. Track whether the people sent to a prep path eventually book, alongside ready-to-start rate.
- A general headline still works; the series stamp and file/calculator icon signal tax preparation.

## Rewrite test
- Too academic: “Researchers surveyed 500 organizations and found [result].”
- Too generic: “Respond faster and follow up.”
- Stronger: “What did the caller know when they hung up?” Then name the promised next step, test it, and keep the exact study scope near its statistic.
- If a source says users were 20% more likely to click, never recast that as “20% more clients.” Pick the correct outcome and ask what downstream measure would decide whether the change was useful.
