# Jay carousel brief template

## Editorial goal & evidence
- Audience / audience question:
- Observable problem and why it matters:
- Decision the reader should make differently:
- Mechanism, tradeoff, or exception:
- Source (title, date, URL, figure/table/section):
- Exact observation: comparison, values/units, denominator, population/time window:
- Evidence class: observed / derived (show calculation) / explicitly illustrative / qualitative only:
- Limit and anything not verified:

## Cover · exact copy and art directions
- Graphics preset ID: select one from the [graphics styles](../graphic-prompts/styles.md).
1. **Topic Label**:
2. **Series Stamp**: Line 1 / Line 2.
3. **Industry Icon**: approved reference or short direction.
4. **Main Headline**:
5. **Context & Takeaway**:
6. **Metric Card**: value or takeaway / comparator and unit / visible scope label if needed.
7. **Fixed Brand Footer**: LOCKED. Reuse the approved Jay footer unchanged unless expressly overridden. Record any override.
8. **Hero Illustration**: one-line topic-specific concept and the selected style’s material treatment.
   - **Graphics prompt (standalone)**: concrete art description, reference roles, composition/scale, palette, material, output format, exclusions. Record stock author, URL and license when applicable.

## Slide 2 · proof and decision
- Headline and takeaway (exact copy):
- Chart/diagram: chart type, values & units, axes/baseline, legends, denominator and time window; no fabricated data.
- Scope label and caveat visible near the visualization:
- Practical next test or boundary:
- Source line (exact copy, with direct URL in brief):

## LinkedIn caption
Final copy in English: hook, context, transferable judgment, failure condition or a practical test. Keep references and relevant hashtags easy to copy. Give sources after the story; give necessary evidence labels next to the claim.

## Checks
- Eight cover fields; no extra number for swipe bar or page count.
- Same claim and evidence throughout; static footer; self-contained art prompt.
- Names or client results attributed only with appropriate evidence/permission.
- Where the source is only qualitative, use a decision diagram or label any illustrative number clearly.
